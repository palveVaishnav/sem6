
drop table mentor;

create table mentor(current_year varchar(20),name varchar(30),roll_no varchar(20),contact_no varchar(30),email varchar(30),class varchar(20),division varchar(20),mentor_name varchar(30));
