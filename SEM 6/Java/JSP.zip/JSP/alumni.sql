drop table alumni;

create table alumni(name varchar(20), email varchar(20),cno varchar(10),occupation varchar(30),pass_year varchar(4),program_name varchar(30));

select * from alumni;
