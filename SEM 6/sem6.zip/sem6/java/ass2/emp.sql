
create table employee(empid int primary key,emp_name varchar(20)  , salary int );
