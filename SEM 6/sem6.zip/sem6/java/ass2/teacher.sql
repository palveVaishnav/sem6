create table Teacher(Teacher_id int primary key , Teacher_name varchar(20));
create table workload(subject_code int primary key ,subject varchar(20) , date varchar(20),time varchar(20),class int , Teacher_id int references Teacher(Teacher_id));/*
insert into teacher values(1,'abc');
insert into workload values (101,'asd','2021/12/1','10:30',1);*/
 
