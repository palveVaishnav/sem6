import java.io.*;
import java.sql.*;

class ass21
{
	public static void main(String args[]) throws  IOException,SQLException,ClassNotFoundException
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		PreparedStatement ps=null;
		try
		{
			Class.forName("org.postgresql.Driver");
			con = DriverManager.getConnection("jdbc:postgresql://192.168.16.252/ty218543","ty218543","");
			if(con == null)
			{
				System.out.println("\nConnection Failed\n");
			}
			else
			{
				int ch,id,sal,result;
				String sql,name;
				System.out.println("\nConection established\n");
				stmt = con.createStatement();
				do
				{
					System.out.println("\nMenu\n1.insert the details of employee\n2.modify employee details\n3.Delete employee\n4.Search employee\n5.veiw all\n6.exit\nEnter the choice:\t");
					ch=Integer.parseInt(br.readLine());
					if(ch==6)
						break;
					switch(ch)
					{
						case 1: System.out.println("enter the employee details u want to insert:\t");
							System.out.println("\nEnter the Id:\t");
							id = Integer.parseInt(br.readLine());
							System.out.println("\nEnter the Name:\t");
							name = br.readLine();
							System.out.println("\nEnter the salary:\t");
							sal = Integer.parseInt(br.readLine());
							sql = "Insert into employee values(?,?,?)";
							ps = con.prepareStatement(sql);
							ps.setInt(1,id);
							ps.setString(2,name);
							ps.setInt(3,sal);
							result = ps.executeUpdate();
							if(result == 1)
							{
								System.out.println("Data inserted successfully");
							}
							break;
						case 2: System.out.println("\nEnetr the id of employee you want to UPDATE:\t");
							id = Integer.parseInt(br.readLine());
							System.out.println("\nEnetr the Updated Name\t");
							name=br.readLine();
							System.out.println("\nEnter the Updated salary:\t");
							sal = Integer.parseInt(br.readLine());

							sql = "Update employee set emp_name = ?,salary = ? where empid=?";

							ps=con.prepareStatement(sql);
							ps.setString(1,name);
							ps.setInt(2,sal);
							ps.setInt(3,id);
							result = ps.executeUpdate();
							if(result==1)
							{
								System.out.println("\nData Updated successfully");
							}break;
						case 3: System.out.println("\nEnter the id of employee u want want to delete:\t");
                                                        id=Integer.parseInt(br.readLine());
                                                        sql = "Delete from employee where empid=?";
                                                        ps = con.prepareStatement(sql);
                                                        ps.setInt(1,id);
                                                        result =ps.executeUpdate();
                                                        if(result == 1)
                                                        {
                                                                System.out.println("\nData deleted successfully");
                                                        }
                                                        break;
                                                case 4: System.out.println("\nEnter the id of employee u wanted to search:\t");
                                                        id=Integer.parseInt(br.readLine());
                                                        sql = "select *from employee where empid= ?";
                                                        ps=con.prepareStatement(sql);
                                                        ps.setInt(1,id);
                                                        rs = ps.executeQuery();
                                                        while(rs.next())
                                                        {
                                                                System.out.println("ID = "+rs.getInt(1)+"\t");
                                                                System.out.println("Name = "+rs.getString(2)+"\t");
                                                                System.out.println("Salary = "+rs.getInt(3)+"\t");
                                                        }
                                                        rs.close();
                                                        break;
						case 5: rs = stmt.executeQuery("Select * from employee");
							while(rs.next())
							{
								System.out.println("ID = "+rs.getInt(1)+"\t");
                                                                System.out.println("Name = "+rs.getString(2)+"\t");
                                                                System.out.println("Salary = "+rs.getInt(3)+"\t");
							}
							rs.close();
							break;
						default : System.out.println("wrong choice re-enter choice:");
							  ch = Integer.parseInt(br.readLine());
							  break;


					}
				}while(ch!=6);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		finally
		{
			stmt.close();
			con.close();
		}
	}
}
							

							




