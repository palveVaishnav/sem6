create table attendence(rollno int primary key , name varchar(20), Class varchar(20),subject varchar(20), total_attended int);

insert into attendence values (1,'abc','12','english',20);


