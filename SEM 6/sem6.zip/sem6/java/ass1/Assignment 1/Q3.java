import java.io.*;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.ArrayList;

public class Q3
{
	public static void main(String[] args)
	{
		Set<String>flavors=new HashSet<>();
		Map<String,Double>prices=new HashMap<>();

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of icecream flavours: ");
		int n=sc.nextInt();
		
		System.out.println("Enter the flavour of icecream : ");
		for(int i=0;i<n;i++)
		{
			String flavor=sc.next();
			flavors.add(flavor);
		}
		System.out.println("Enter the prices for the flavor: ");
		for(String flavor:flavors)
		{
			double price=sc.nextDouble();
			prices.put(flavor,price);
		}

		
		while(true)
		{
			System.out.println("Menu :");
			System.out.println("1.Search for specif flavor ");
			System.out.println("2.Sort all the flavors");
			System.out.println("3.Exit ");
			System.out.println("Enter your choice :");
			int choice=sc.nextInt();

			switch(choice)
			{
				case 1:
					System.out.println("Enter the flavor to search for: ");
					String flavorToSearch=sc.next();
					if(flavors.contains(flavorToSearch))
					{
						System.out.println("Flavor found!! ");
					}
					else
					{
						System.out.println("Flavor not found!!");
					}
					break;

				case 2:
					System.out.println("Sorting flavors.....");
					List<String>sortedFlavors=new ArrayList<>(flavors);

					Collections.sort(sortedFlavors);

					System.out.println("Sorted flavors:"+sortedFlavors);
					break;

				case 3:
					System.out.println("Exiting program.....");
					sc.close();
					return;
				default: 
					System.out.println("Invalid Choice.Try Again....");
					break;
			}
		}
	}
}











































		

