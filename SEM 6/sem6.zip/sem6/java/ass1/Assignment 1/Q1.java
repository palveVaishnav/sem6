import java.io.*;
import java.util.*;

public class Q1
{
	public static void main(String []args) throws IOException
	{
 		Hashtable person = new Hashtable();

		int n, i;

		String name,ph;

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.print("\n Enter number of persons : ");
		
		n = Integer.parseInt(br.readLine());
		
		for(i=0;i<n;i++)
		{
			System.out.print("\n Enter name of person :");
			name=br.readLine();

			System.out.print("\n Enter phone number of person:");
			ph=br.readLine();
			person.put(name,ph);

	
		}
		System.out.print("Details of person : "+person+"\n");

		System.out.print("Enter name of person for searching:");

		name = br.readLine();
	
		if(person.containsKey(name))
		{
			System.out.print("\n Person Found\n");
			
			System.out.print("Name:"+name+"\nContact:"+person.get(name)+"\n");

		}
		else
		{
			System.out.print("\n No Person Found\n");
		}				
		

	}

}
