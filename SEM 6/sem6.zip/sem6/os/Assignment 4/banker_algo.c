#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int n,m,p,elm=0,**need,*work,*available,**max,**allocation,i,j,*safeseq,*finish,**request;
char ch;

void accept(){
	printf("\nEnter the number or processes:");
	scanf("%d",&n);
	if(n<=0){
		printf("\nInvalid number of processes.Enter again:");
		scanf("%d",&n);
	}
	
	printf("\nEnter the number of resources:");
	scanf("%d",&m);
	if(m<=0){
		printf("\nInvalid number of resources.Enter again:");
		scanf("%d",&m);
	}
	max=(int**)malloc((n)*sizeof(int*));
	for(i=0;i<n;i++){
		max[i]=(int*)malloc((m)*sizeof(int));
	}
	printf("Enter the max matrix:");
	for(i=0;i<n;i++){
		for(j=0;j<m;j++){
			scanf("%d",&max[i][j]);
		}
	}
	allocation=(int**)malloc(n*sizeof(int*));
	for(i=0;i<n;i++)
		allocation[i]=(int*)malloc(m*sizeof(int));
	printf("\nEnter the allocation matrix:");
	for(i=0;i<n;i++){
		for(j=0;j<m;j++){
			scanf("%d",&allocation[i][j]);
			if(allocation[i][j]>max[i][j]){
				printf("Allocation cannot be greater than max.Enter again:");
				scanf("%d",&allocation[i][j]);
			}
		}
	}
	available=(int*)malloc(m*sizeof(int));
	printf("\nEnter the available resources:");
	for(i=0;i<m;i++)
		scanf("%d",&available[i]);
}

void display(){
	printf("\nMax:\n");
	for(i=0;i<n;i++){
		for(j=0;j<m;j++){
			printf("%d\t",max[i][j]);
		}
		printf("\n");
	}
	printf("\nAllocation:\n");
	for(i=0;i<n;i++){
		for(j=0;j<m;j++){
			printf("%d\t",allocation[i][j]);
		}
		printf("\n");
	}
}

void calneed(){
	need=(int**)malloc((n)*sizeof(int*));
	for(i=0;i<n;i++){
		need[i]=(int*)malloc((m)*sizeof(int));
	}
	for(i=0;i<n;i++){
		for(j=0;j<m;j++){
			need[i][j]=max[i][j]-allocation[i][j];
		}
	}
	printf("\nNeed:\n");
	for(i=0;i<n;i++){
		for(j=0;j<m;j++){
		printf("%d\t",need[i][j]);
		}
		printf("\n");
	}
}

void calsafeseq(){
	work=(int*)malloc((m)*sizeof(int));
	safeseq=(int*)malloc((n)*sizeof(int));
	finish=(int*)malloc((n)*sizeof(int));
	elm=0;
	for(i=0;i<m;i++)
		work[i]=available[i];
	int y=0,k;
	for(i=0;i<n;i++){
		finish[i]=0;
	}
	for(k=0;k<n;k++){
		for(i=0;i<n;i++){
			if(finish[i]==0){
				int flag=0;
				for(j=0;j<m;j++){
					if(need[i][j]>work[j]){
						flag=1;
						break;
					}
				}
				
				if(flag==0){
					safeseq[elm++]=i;
					for(y=0;y<m;y++){
						work[y]=work[y]+allocation[i][y];
					}
					finish[i]=1;
				}
			}
		}
	}
	int flag=1;
	for(i=0;i<n;i++){
		if(finish[i]==0){
			flag=0;
			printf("\nSystem is not safe.");
			break;
		}
	}
	if(flag==1){
		printf("\nSystem is in safe state.\nThe safe sequence is:\n");
		for(i=0;i<n;i++){
			printf("%d\t",safeseq[i]);
		}
	}
	free(safeseq);
}

void calrequest(){
	request=(int**)malloc((n)*sizeof(int*));
	for(i=0;i<n;i++){
		request[i]=(int*)malloc((m)*sizeof(int));
	}
	
	do{
		printf("\nDoes any process request for any other?(Y/N):");
		scanf(" %c",&ch);
		if(ch=='N' || ch=='n'){
			break;
		}
		else{
			printf("\nEnter the requesting process:");
			scanf("%d",&p);
			printf("Enter the resources:");
			for(i=0;i<m;i++){
				scanf("%d",&request[p][i]);
				if(request[p][i]>need[p][i]){
					printf("\nInvalid request for resources.");
					exit(0);
				}
			}
			printf("\nAvailable:");
			for(i=0;i<m;i++){
				allocation[p][i]=allocation[p][i]+request[p][i];
				available[i]=available[i]-request[p][i];
				printf("\t%d\t",available[i]);
				need[p][i]=need[p][i]-request[p][i];
			}
			display();
			calneed();
			calsafeseq();
		}
	}while(ch=='Y'||ch=='y');
}

int main(){
	accept();
	display();
	calneed();
	calsafeseq();
	calrequest();	
}
