drop table movie cascade;
drop table actor cascade;
drop table movie_actor cascade;



--movie(no,name,year)
create table movie(movie_no int primary key, movie_name varchar(30), release_year int);
insert into movie values (1,'pathan',2018);
insert into movie values (2,'housefull',2022);




--actor(no,name)
create table actor(actor_no int primary key, name varchar(30));
insert into actor values(101, 'akshay');
insert into actor values(102,'ritesh');




--manytomany
create table movie_actor(movie_no int references movie(movie_no) on delete cascade, actor_no int references actor(actor_no ) on delete cascade, rate int);
insert into movie_actor values(1,101,50000);
insert into movie_actor values(2,102,40000);
