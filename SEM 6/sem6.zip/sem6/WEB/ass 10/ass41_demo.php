<html>
<?php
	$bg=$_COOKIE['bg'];
	$ft=$_COOKIE['fc'];
?>
	<body bgcolor="<?=$bg?>" text="<?=$ft?>">
<h1> hello this arial</h1>
<br><h2>welcome</h2>
<br>
</body>
</html>

