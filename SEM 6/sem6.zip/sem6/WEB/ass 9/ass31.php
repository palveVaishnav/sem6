<?php
	if(file_exists('student.text'))
	{
		$fp = fopen('student.text','r');
		echo"<br>STUDENT DETAILS:<br><br>";
		echo "<table border=2 align=center>";
		echo "<tr><td align=center>Roll no.</td>";
		echo"<td align=center>Name</td>";
		echo "<td align=center>Electronic</td>";
		echo "<td align=center>Computer</td>";
		echo "<td align=center>Maths</td>";
		echo "<td align=center>Total</td>";
		echo "<td align=center>Percentage</td></tr>";
		while (!feof($fp))
		{
			$d=fgets($fp);
			$s=explode(',',$d);
			if(!empty($s[0]) && !empty($s[1]) && !empty($s[2])&& !empty($s[3])&& !empty($s[4])){
				$m1=$s[2];
				$m2=$s[3];
				$m3=$s[4];
				$total=$m1+$m2+$m3;
				$percent=($total /300)*100;
				/*echo "hello";*/
				echo "<tr><td align=center>$s[0]</td>";
                		echo "<td align=center>$s[1]</td>";
                		echo "<td align=center>$s[2]</td>";
                		echo "<td align=center>$s[3]</td>";
                		echo "<td align=center>$s[4]</td>";
                		echo "<td align=center>$total</td>";
				echo "<td align=center>$percent%</td></tr>";
			}
		}

		echo "</table>";
	}
?>

