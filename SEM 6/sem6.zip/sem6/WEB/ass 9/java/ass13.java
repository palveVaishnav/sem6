import java.io.*;
import java.util.*;

class ass13
{
	public static void main(String args[]) throws IOException
	{
		BufferedReader br =new BufferedReader (new InputStreamReader(System.in));
	        ArrayList a1=new ArrayList();
			// inserting flavors
		System.out.println("\nenter the  number of flavors :");
		int n = Integer.parseInt(br.readLine());	
		System.out.println("enter the flavors of ice-cream");
		for(int i=0 ; i<n ; i++)
		{
			System.out.println("enter the "+(i+1)+" flavor of ice-cream");
			String flavor = br.readLine();
			if(!a1.contains(flavor))
			{
				a1.add(flavor);
			}
			else
			{
				System.out.println("\nDuplictae values are not allowed!!");
				i--;
				continue;
			}
		}
		//searching 
		System.out.println("\nEnter the flavor to be searched:\t");
		String flavor= br.readLine();	
		if(a1.contains(flavor))
		{
			System.out.println("\nflavor found!!\n");

		}
		else
		{
			System.out.println("\nflavor not found!");
		}
		
		//sorting
		System.out.println("\nlist before sorting :\n"+a1); 
		Collections.sort(a1);
		System.out.println("\nsorted list:\n"+a1);
		
		Hashtable hs = new Hashtable();
		for(int i=0 ; i<n ;i++)
		{
			System.out.println("\nEnter price for flavor "+a1.get(i)+":");
			float price=Float.parseFloat(br.readLine());
			hs.put(a1.get(i),price);
		}
		System.out.println("\nHash Table \n"+hs);

	}
}




