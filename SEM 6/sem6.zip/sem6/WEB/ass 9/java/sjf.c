#include<stdio.h>
#include<stdlib.h>
typedef struct process
{
	int pid;
	float at,bt,ct,tat,wt,et;
	struct process *next;
}process;
int pi;
float total_wait_time=0,total_turn_around_time=0,io=0;
int n,total_burst=0;
void swap_process(process*ptr1,process*ptr2)
{
	float i;
	int j;

	j=ptr2->pid;
	ptr1->pid=j;

	i=ptr2->at;
	ptr2->at=ptr1->at;
	ptr1->at=i;

	i=ptr2->bt;
	ptr2->bt=ptr1->bt;
	ptr1->bt=i;

	i=ptr2->ct;
	ptr2->ct=ptr1->ct;
	ptr1->ct=i;

	i=ptr2->tat;
	ptr2->tat=ptr1->tat;
	ptr1->tat=i;

	i=ptr2->wt;
	ptr2->wt=ptr1->wt;
	ptr1->wt=i;

	i=ptr2->et;
	ptr2->et=ptr1->et;
	ptr1->et=i;

}

process *get_process(float a,float b)
{
	process *pr=(process*)malloc(sizeof(process));
	pr->at=a;
	pr->bt=b;
	pr->pid=pi++;
	pr->next=NULL;
	return pr;
}

void insert(process *ptr,float a,float b)
{
	total_burst+=b;
	process *pro,*temp;
	pro=get_process(a,b);
	while(ptr->next!=NULL)
	{
		ptr=ptr->next;
	}
	ptr->next=pro;
}

void sort(process*ptr)
{
	process *t,*s,*temp;
	t=ptr;
	while(t!=NULL)
	{
		s=t->next;
		while(s!=NULL)
		{
			if(t->ct > s->ct)
			{
				swap_process(t,s);
			}
			s=s->next;
		}
		t=t->next;
	}
}

void sjf(process *ptr)
{
	int id;
	float cpt=0,time=0;
	int min=total_burst;
	process *temp,*task;
	while(time<=total_burst)
	{
		task=NULL;
		temp=ptr->next;
		min=total_burst;
		while(temp!=NULL)
		{
			if(temp->pid==id && temp->et==0)
			temp->at=cpt+io;
			temp=temp->next;
		}
		temp=ptr->next;
		while(temp!=NULL)
		{
			if(temp->et==0)
			{
				if((time>=temp->at)&&(temp->bt<min))
				{
					min=temp->bt;
					task=temp;
				}
			}
			temp=temp->next;
		}
		if(task==NULL)
		{
			time++;
		}
		else
		{
			time+=task->bt;
			task->et+=1;
			task->wt=time-(task->at+task->bt);
			task->tat=time-(task->at);
			task->ct=time;
			cpt=task->ct;
			id=task->pid;
		}
	}
}

void display(process *ptr)
{
	process *temp = ptr->next;
	printf("\n\nprocess\tBurst time\tArrival time\tfinish time \t waiting time\tTurn Around Time\n");
	while( temp!=NULL)
	{
		printf("P[%d]\t\t%d\t\t%d\t\t%d\t\t%d\t\t%d\n",temp->pid,temp->bt,temp->at,temp->ct,temp->wt,temp->tat);
		temp = temp->next;
	}
	printf("\n");/*
	process *temp,*t;
	temp = ptr->next;
	t=ptr;
	printf("\n\nprocess\tBurst time\tArrival time\tfinish time \t waiting time\tTurn Around Time\n");
	while( temp!=NULL)
	{
		temp->ct=temp->tat+temp->at;
		printf("P[%d]\t\t%d\t\t%d\t\t%d\t\t%d\t\t%d\n",temp->pid,temp->bt,temp->at,temp->ct,temp->wt,temp->tat);
		temp = temp->next;
	}
	printf("\n");*/
/*	process *temp,*t;
	temp=ptr->next;
	t=ptr;
	while(temp!=NULL)
	{
		temp->ct=temp->tat+temp->at;
		temp=temp->next;
	}*/
}

void complete_time(process *ptr)
{
	process *temp,*t;
	temp=ptr->next;
	t=ptr;
	while(temp!=NULL)
	{
		temp->ct=temp->tat+temp->at;
		temp=temp->next;
	}
}

void ganttchart(process *ptr)
{
	process *temp=ptr->next;
	process *t=ptr;
	int i;
	printf("\n-------------Gantt Chart-------------\n\n");
	while(temp!=NULL)
	{
		if((temp->ct)-(temp->bt)!=t->ct)
		{
			printf("|CPU-IDLE|--P[%d]--",temp->pid);
		}
		else
		{
			printf("|--P[%d]--",temp->pid);
		}
		t=temp;
		temp=temp->next;
	}
	printf("|\n");
	temp=ptr->next;
	t=ptr;
	while(temp!=NULL)
	{
		if((temp->ct)-(temp->bt)!=t->ct)
		{
			printf("    %3.1f    %3.1f  ",(temp->ct)-(temp->bt),temp->ct);
		}
		else
		{
			printf("   %3.1f",temp->ct);
		}
		t=temp;
		temp=temp->next;
	}
	printf("\n");
	printf("\n----------------------------\n");
}

void wt_and_tat(process *ptr)
{
	process*temp=ptr->next;
	while(temp!=NULL)
	{
		total_turn_around_time+=temp->tat;
		total_wait_time+=temp->wt;
		temp=temp->next;
	}
	float avg_waiting_time = (float) total_wait_time / n;
	float avg_turnaround_time = (float)total_turn_around_time/ n;
	printf("Average waiting time: %f\n", avg_waiting_time);
	printf("Average turnaround time: %f\n", avg_turnaround_time);
}

int main()
{
	int i;
	float a,b;
	pi=1;
	process*START=(process*)malloc(sizeof(process));
	START->next=NULL;
	printf("Enter the number of the Processes:");
	scanf("%d",&n);
	while(n<1)
	{
		printf("Number of the process can't be less than 1 \nEnter Again:");
		scanf("%d",&n);
	}
	for(i=0;i<n;i++)
	{
		printf("Process P[%d]\n",i+1);
		printf("Arrival Time:");
		scanf("%f",&a);
		while(a<0)
		{
			printf("Arrival time cannot be less than 1\nEnter Again!");
			scanf("%f",&a);
		}
		printf("BUrust Time:");
		scanf("%f",&b);
		while(b<0)
		{
			printf("Burst time cannot be less than 1\nEnte Again");
			scanf("%f",&b);
		}
		insert(START,a,b);
		printf("\n");
	}
	sjf(START);
	complete_time(START);
	int ch;
	printf("Do you want next Arrival time(if Yes type 1 and No type 0)");
	scanf("%d",&ch);
	if(ch)
	{
		process *new=START->next;
		printf("Enter the fixed IO time:");
		scanf("%f",&io);
		pi=1;
		int proc=0;
		while(proc<n)
		{
			proc++;
			printf("Second burst time for process %d :",new->pid);
			scanf("%f",&b);
			while(b<n)
			{
				printf("Burst Time cannot be less than 0\nEnter Again");
				scanf("%f",&b);
			}
			a=new->ct+io;
			new->et=0;
			insert(START,a,b);
			printf("\n");
			new=new->next;
		}
	}
	sjf(START);
	complete_time(START);
	wt_and_tat(START);
	sort(START);
	display(START);
	ganttchart(START);
	return 0;	

}


