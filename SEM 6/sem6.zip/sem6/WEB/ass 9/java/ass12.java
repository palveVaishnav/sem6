import java.io.*;
import java.util.*;

class ass12
{
	public static void main (String args[]) throws IOException
	{
		BufferedReader br = new BufferedReader (new InputStreamReader (System.in));

		LinkedList ll1 = new LinkedList();
		LinkedList ll2 = new LinkedList();
		int n1, n2;
		System.out.println("Enter number of elements in linked list 1:\t");
		n1 = Integer.parseInt(br.readLine());
		System.out.println("Enter the elements in linked list 1");
		for(int i=0 ; i<n1 ; i++)
		{
			String item = br.readLine();
			if(!ll1.contains(item))
			{
				ll1.add(item);
			}
		}
		System.out.println("Enter number of elements in linked list 2:\t");
		n2 = Integer.parseInt(br.readLine());
		System.out.println("Enter the elements in linked list 2");
                for(int i=0 ; i<n2 ; i++)
                {
                        String item = br.readLine();
                        if(!ll2.contains(item))
                        {
                                ll2.add(item);
                        }
                }
		Collections.sort(ll1);
		Collections.sort(ll2);
		System.out.println("\nLinked list 1 \t\t linked list 2");
		System.out.println("\n");
		System.out.println("\n"+ll1+" \t\t "+ll2);
		System.out.println("\n");

		// union operation 
		LinkedList ll3 = new LinkedList();
		for(int i=0; i<ll1.size() ; i++)
		{
			ll3.add(ll1.get(i));
		}
		for(int i=0 ; i<ll2.size(); i++)
		{
			if(!ll1.contains(ll2.get(i)))
			{
				ll3.add(ll2.get(i));
			}

		}
		System.out.println("Linked list operation:");
		System.out.println("Union : "+ll3);
		

		// intersection operation 
		LinkedList ll4 = new LinkedList();
		for (int i=0 ; i<ll1.size() ; i++)
		{
			ll4.add(ll1.get(i));
		}
		ll4.retainAll(ll2);
		System.out.println("Intersection : "+ll4);
		if (ll1.size() == ll2.size())
		{
			LinkedList ll5 = new LinkedList();
			System.out.println("\nCombining Elements");
			for(int i= 0; i<ll1.size() ; i++)
			{
				ll5.add(ll1.get(i));
			}
			for(int i= 0; i<ll2.size() ; i++)
                        {
                                ll5.add(ll2.get(i));
                        }
			System.out.println(ll5);
		}




	}
}



