// assignment 1 - FCFS 
#include<stdio.h>
#include<stdlib.h>

struct job
{
	int atime;//arrival time
	int btime ; //brust time
	int ft; //final time
	int tat; //turn around time
	int wt; //waiting time
}p[10];

int arr[10],brust[10],n,rq[10],no_rq=0,time=0;

int addrq() //adding request
{
	for(int i=0; i<n ; i++)
	{
		if(arr[i]==time)
		{
			rq[no_rq]= i;
			no_rq ++;
		}
	}
}

int select_job()
{
	int i,j;
	if (no_rq == 0)
		return 1;
	j=rq[0];
	deleteq(j);
	return j;
}


int deleteq(int j)
{
	int i;
	for( i=0 ; i< no_rq; i++)
	{
		if(rq[i] == j)
			break;
		for(i=i+1 ; i<no_rq ; i++)
			rq[i-1] = rq[i];
		no_rq--;
		
	}
}

int fshall()
{
	 for(int i= 0; i<n; i++)
	 {
		 if(brust[i]!=0)
			return -1;
		 return 1;
	 }
}


int main()
{
	int i ,j;
	printf("\n enter the no. of  processess\t:\t");
	scanf("%d",&n);
	printf("\n");

	for(i=0; i<n ; i++)  // Assigning arrival time of the processess
	{
		printf("\nEnter the Arrival time p%d : ",i);
		scanf("%d",&p[i].atime);
		arr[i] = p[i].atime;
	}
	printf("\n");
	printf("printing arrival time");
	printf("\n");

	for(i=0; i<n ; i++)  //  arrival time of the processess
        {
                printf("\nEnter the Arrival time p%d : ",i);
                printf("%d\n",&p[i].atime);
                arr[i] = p[i].atime;
        }
	
	printf("\n");
	
	for(i=0; i<n ; i++)  //  entering brust time of the processess
        {
                printf("\nEnter the brust time p%d : ",i);
                scanf("%d",&p[i].btime);
                brust[i] = p[i].btime;
        }

	printf("\n");
	
	for(i=0; i<n ; i++)  // brust time of the processess
        {
                printf("\nEnter the Arrival time p%d : ",i);
                printf("%d\n",&p[i].btime);
                brust[i] = p[i].btime;
        }
	
	printf("\n");
	addrq();//adding process
	//process starting 
	printf("\n\t***GANTT CHART***\n");
	while(1)
	{
		j=select_job(); //searching the process
		if(j == -1)
		{
			printf("CPU is ideal!");
			time++;
			addrq();
		}
		else
		{
			while(brust[j]!=0)
			{
				printf("|\t %d",j);
				brust[j]--;
				time++;
				addrq();
			}
			p[j].ft = time;
		}
		if(fshall() == 1)
		{
			break;
		}
	}

	printf("\n=============================================\n");
	printf("\n| Process ID | A.T | B.T | F.T | W.T | TAT \n");
	printf("\n=============================================\n");
	int tat=0,wt=0;
	for(i=0; i<n;i++)
	{
		p[i].tat = p[i].ft - p[i].atime;
		p[i].wt = p[i].tat - p[i].btime;
		printf("\n  P%d    |  %d  |  %d  |  %d  |  %d  |  %d |",i,p[i].atime,p[i].btime,p[i].ft,p[i].wt,p[i].tat);
	        tat += p[i].tat;
		wt += p[i].wt;
	}
	float average_tat = tat/n; 
	float average_wt = wt/n;
	printf("\nAverage of waiting time is : %f " ,average_wt);
	printf("\nAverage of trun around time is : %f " ,average_tat);
}


	





