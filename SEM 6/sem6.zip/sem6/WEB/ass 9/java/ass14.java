import java.io.*;
import java.util.*;
class student
{
	String name;
	int rollno;
	int age;
	public student(int rollno, String name , int age)
	{
		this.rollno = rollno;
		this.name = name;
		this.age = age;
	}
	public String toString()
	{
		return "Roll no: "+rollno+"\nName: "+name+"\nAge: "+age ;
	}
}

class sortByName implements Comparator<student>
{
	public int compare(student a, student b)
	{
		return a.name.compareTo(b.name);
	}
}

class sortByAge implements Comparator<student>
{
	public int compare(student a , student b)
	{
		if(a.age == b.age)
			return 0;
		else if (a.age > b.age)
			return 1;
		return -1;
	}
}
class ass14
{
	public static void main(String args[]) throws IOException
	{
		ArrayList <student> al = new ArrayList<student>();
		al.add(new student(1,"riya",15));
		al.add(new student(2,"piya",10));
		al.add(new student(3,"tiya",11));
		System.out.println("\n\nstudent details");


		for(student s:al)
		{
			System.out.println("\nRollno.:"+s.rollno+"\nName:"+s.name+"\nAge:"+s.age);
		}	
		Collections.sort(al, new sortByName());
		System.out.println("\n\nsorted list by name:\n");
		for(student s:al)
                {
                        System.out.println("\nRollno.:"+s.rollno+"\tName:"+s.name+"\tAge:"+s.age);
                }

		Collections.sort(al, new sortByAge());
		System.out.println("\n\nsorted list by age:\n");
                for(student s:al)
                {
                        System.out.println("\nRollno.:"+s.rollno+"\tName:"+s.name+"\tAge:"+s.age);
		}


	}
}


