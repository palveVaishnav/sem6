import java.util.*;
import java.io.*;
class ass11
{
	public static void main(String args[]) throws IOException
	{
		Hashtable hs= new Hashtable();
		hs.put ("Heena",1234567);
		hs.put ("Leena",9087654);
		hs.put("Meena",6589741);
		Enumeration keys = hs.keys();
		Enumeration values = hs.elements();
		while (keys.hasMoreElements() && values.hasMoreElements())
		{
			System.out.println(keys.nextElement()+" "+values.nextElement());
		}
		System.out.println("Enter the Person name you want to search :");
		BufferedReader br = new BufferedReader (new InputStreamReader(System.in));
		String name = br.readLine();
		keys = hs.keys();
		values = hs.elements();
		int flag = 0;
		while (keys.hasMoreElements() && values.hasMoreElements())
		{
			String n1 = (String) keys.nextElement();
			if( name.equals(n1))
			{
				flag = 1;
				System.out.println("Record found :\n"+ name +" "+ values.nextElement());
			       break;
			}
			else if (flag == 0)
			{
				System.out.println("Record not matched ");
			}
			else
                        {
                                values.nextElement();
                        }

		}
	}
}

